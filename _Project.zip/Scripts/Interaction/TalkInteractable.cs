﻿using UnityEngine;

namespace TehranNoir.Interaction
{
    /// <summary>
    /// آدم قابل گفتگو. فقط اسم و نقش را می‌گیرد؛ دکمه و متن خودکارند.
    /// </summary>
    public class TalkInteractable : Interactable
    {
        [Header("Person")]
        [SerializeField] private string displayName = "Unknown";
        [SerializeField] private string role = "";

        [Tooltip("فعلاً برای تست؛ بعداً با سیستم دیالوگ جایگزین می‌شود")]
        [SerializeField] private bool logInteraction = true;

        // همیشه Talk است؛ فیلد Action در Inspector برای این کلاس نادیده گرفته می‌شود
        public override InteractionAction Action => InteractionAction.Talk;

        public override string Detail =>
    string.IsNullOrWhiteSpace(role) ? displayName : $"{displayName}\n{role}";

        public override void Interact(GameObject interactor)
        {
            if (logInteraction)
                Debug.Log($"{displayName} ({role}): ...", this);
        }
    }
}